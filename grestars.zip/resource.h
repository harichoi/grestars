//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by grestar.rc
//
#define IDB_DOWNMASK                    101
#define IDB_DOWN                        102
#define IDC_CURSOR1                     103
#define IDB_ALLCENTER                   104
#define IDB_ALLCENTERMASK               105
#define IDB_FARMER                      106
#define IDB_FARMERMASK                  107
#define IDB_MONEY                       108
#define IDB_ALLCENTER2                  109
#define IDB_FARMER2                     110
#define IDB_FARMER3                     111
#define IDB_MAKING2                     112
#define IDB_MAKING                      113
#define IDI_ICON1                       114
#define IDB_SOLDIERCREATOR              115
#define IDB_SOLDIERCREATORMASK          116
#define IDB_BASIC                       117
#define IDB_BASICMASK                   118
#define IDB_BOMB                        119
#define IDB_SOLDIERCREATOR2             120
#define IDB_NEXTBASIC                   121
#define IDB_NEXTBASICMASK               122
#define IDB_FACTORY                     123
#define IDB_FACTORY2                    124
#define IDB_FACTORY3                    125
#define IDB_FACTORY4                    126
#define IDB_FACTORY5                    127
#define IDB_FACTORY6                    128
#define IDB_FACTORY10                   129
#define IDB_FACTORY11                   130
#define IDB_FACTORY12                   131
#define IDB_FACTORY13                   132
#define IDB_FACTORY14                   133
#define IDB_TANK                        134
#define IDB_TANKMASK                    135

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        136
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
